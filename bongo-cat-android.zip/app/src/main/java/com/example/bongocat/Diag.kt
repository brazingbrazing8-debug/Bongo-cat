package com.example.bongocat

object Diag {
    @Volatile var motion = 0
    @Volatile var keys = 0
    @Volatile var hover = 0
    @Volatile var err = "nenhum"
}
