package com.example.bongocat

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

object SignatureCheck {
    // SHA-256 da assinatura original do Bongo Cat. Se o APK for reempacotado
    // (por exemplo pelo MT Manager) a assinatura muda e este valor nao bate.
    private const val EXPECTED = "F238C4193B837BFB787E2D9878434EC7D3E46F92C652A5A73B879FBDFCE05FC7"

    @Volatile
    private var cached: Boolean? = null

    fun isOriginal(ctx: Context): Boolean {
        cached?.let { return it }
        val ok = try {
            val hashes = currentHashes(ctx)
            hashes.any { it.equals(EXPECTED, ignoreCase = true) }
        } catch (t: Throwable) {
            // Se nao for possivel checar, nao bloqueia o app por um erro nosso.
            true
        }
        cached = ok
        return ok
    }

    private fun currentHashes(ctx: Context): List<String> {
        val pm = ctx.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val si = info.signingInfo
            if (si == null) {
                emptyArray()
            } else if (si.hasMultipleSigners()) {
                si.apkContentsSigners
            } else {
                si.signingCertificateHistory
            }
        } else {
            @Suppress("DEPRECATION")
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES)
            @Suppress("DEPRECATION")
            info.signatures ?: emptyArray()
        }
        val md = MessageDigest.getInstance("SHA-256")
        return sigs.map { sig ->
            md.reset()
            md.digest(sig.toByteArray()).joinToString("") { b -> "%02X".format(b) }
        }
    }
}
