package com.example.bongocat

object KeyMaps {
    val K_TECLADO = arrayOf("lctrl", "lshift", "r", "down", "right", "left", "up")
    val S_OSU = arrayOf("1", "2", "3", "4", "5", "6", "7", "q", "e", "r", "space", "a", "d", "s", "w")
}
