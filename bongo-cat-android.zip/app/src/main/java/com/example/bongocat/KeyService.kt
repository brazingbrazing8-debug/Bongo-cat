package com.example.bongocat

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class KeyService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        Diag.keys++
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            BongoService.instance?.keyDown()
        }
        return false
    }
}
