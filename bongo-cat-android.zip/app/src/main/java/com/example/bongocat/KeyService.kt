package com.example.bongocat

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class KeyService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        if (!SignatureCheck.isOriginal(this)) {
            stopSelf()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        Diag.keys++
        val svc = BongoService.instance
        if (svc != null) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                svc.keyDown(event.keyCode, event.repeatCount > 0)
            } else if (event.action == KeyEvent.ACTION_UP) {
                svc.keyUp(event.keyCode)
            }
        }
        return false
    }
}
