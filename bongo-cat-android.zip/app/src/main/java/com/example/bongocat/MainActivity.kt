package com.example.bongocat

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val accent = 0xFF6C5CE7.toInt()
    private val ink = 0xFF2D2650.toInt()
    private val soft = 0xFF7A7499.toInt()
    private val mp = ViewGroup.LayoutParams.MATCH_PARENT
    private val wc = ViewGroup.LayoutParams.WRAP_CONTENT

    private var refreshAll: (() -> Unit)? = null
    private val poll = Handler(Looper.getMainLooper())
    private val pollRun = object : Runnable {
        override fun run() {
            refreshAll?.invoke()
            poll.postDelayed(this, 2000)
        }
    }

    override fun onResume() {
        super.onResume()
        poll.removeCallbacks(pollRun)
        poll.post(pollRun)
    }

    override fun onPause() {
        poll.removeCallbacks(pollRun)
        super.onPause()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        return g
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(Color.WHITE, 20)
        c.elevation = dp(3).toFloat()
        c.setPadding(dp(18), dp(16), dp(18), dp(18))
        val lp = LinearLayout.LayoutParams(mp, wc)
        lp.setMargins(0, 0, 0, dp(14))
        c.layoutParams = lp
        return c
    }

    private fun heading(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 18f
        t.setTextColor(ink)
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(0, 0, 0, dp(6))
        return t
    }

    private fun caption(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(soft)
        t.setPadding(0, dp(8), 0, dp(4))
        return t
    }

    private fun pill(text: String, color: Int): Button {
        val b = Button(this)
        b.text = text
        b.setAllCaps(false)
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.background = round(color, 14)
        b.setPadding(dp(16), dp(10), dp(16), dp(10))
        return b
    }

    private class StatusRow(
        val root: LinearLayout,
        val dot: View,
        val sub: TextView,
        val btn: Button
    )

    private fun statusRow(title: String): StatusRow {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        val dot = View(this)
        val dlp = LinearLayout.LayoutParams(dp(14), dp(14))
        dlp.setMargins(0, 0, dp(12), 0)
        dot.layoutParams = dlp
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = LinearLayout.LayoutParams(0, wc, 1f)
        val t = TextView(this)
        t.text = title
        t.textSize = 15f
        t.setTextColor(ink)
        t.setTypeface(null, Typeface.BOLD)
        val s = TextView(this)
        s.textSize = 12f
        s.setTextColor(soft)
        col.addView(t)
        col.addView(s)
        val b = pill("Ativar", accent)
        b.textSize = 13f
        row.addView(dot)
        row.addView(col)
        row.addView(b)
        return StatusRow(row, dot, s, b)
    }

    private fun paintStatus(r: StatusRow, on: Boolean, sub: String, btnText: String) {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (on) 0xFF2EB872.toInt() else 0xFFE5484D.toInt())
        r.dot.background = g
        r.sub.text = sub
        r.btn.text = btnText
    }

    private fun segmented(labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val tvs = ArrayList<TextView>()
        fun paint(sel: Int) {
            for (i in tvs.indices) {
                val t = tvs[i]
                t.background = round(if (i == sel) accent else 0xFFE9E5F7.toInt(), 12)
                t.setTextColor(if (i == sel) Color.WHITE else 0xFF3D3560.toInt())
            }
        }
        for (i in labels.indices) {
            val t = TextView(this)
            t.text = labels[i]
            t.gravity = Gravity.CENTER
            t.textSize = 14f
            t.setPadding(dp(6), dp(12), dp(6), dp(12))
            val lp = LinearLayout.LayoutParams(0, wc, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            t.layoutParams = lp
            t.setOnClickListener {
                paint(i)
                onPick(i)
            }
            tvs.add(t)
            row.addView(t)
        }
        paint(selected)
        return row
    }

    private fun switchRow(prefs: SharedPreferences, title: String, key: String, def: Int): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        val t = TextView(this)
        t.text = title
        t.textSize = 15f
        t.setTextColor(ink)
        t.layoutParams = LinearLayout.LayoutParams(0, wc, 1f)
        val sw = Switch(this)
        sw.isChecked = prefs.getInt(key, def) == 1
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putInt(key, if (on) 1 else 0).apply()
        }
        row.addView(t)
        row.addView(sw)
        return row
    }

    private fun seekRow(
        prefs: SharedPreferences,
        title: String,
        key: String,
        min: Int,
        max: Int,
        def: Int,
        suffix: String
    ): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(10), 0, dp(2))
        val label = TextView(this)
        label.textSize = 15f
        label.setTextColor(ink)
        val v0 = prefs.getInt(key, def).coerceIn(min, max)
        label.text = title + ": " + v0 + suffix
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = v0 - min
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                label.text = title + ": " + v + suffix
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(label)
        box.addView(sb)
        return box
    }

    private fun spinnerRow(prefs: SharedPreferences, key: String, names: Array<String>): Spinner {
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val saved = prefs.getInt(key, 0)
        val sel = if (saved in names.indices) saved else 0
        if (sel != saved) prefs.edit().putInt(key, sel).apply()
        sp.setSelection(sel)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt(key, pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return sp
    }

    private fun openAccessibility() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun shizukuAction() {
        if (!ShizukuInput.available()) {
            val li = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (li != null) {
                startActivity(li)
            } else {
                Toast.makeText(this, "Shizuku nao instalado", Toast.LENGTH_LONG).show()
                try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api"))
                    )
                } catch (t: Throwable) {
                    try {
                        startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                        )
                    } catch (t2: Throwable) {
                    }
                }
            }
        } else if (!ShizukuInput.granted()) {
            try {
                Shizuku.requestPermission(1234)
            } catch (t: Throwable) {
                Toast.makeText(this, "Shizuku nao encontrado", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Shizuku pronto!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SignatureCheck.isOriginal(this)) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Bongo Cat")
                .setMessage(
                    "Este APK foi modificado ou reempacotado e nao pode ser executado. " +
                        "Baixe o Bongo Cat original."
                )
                .setCancelable(false)
                .setPositiveButton("Fechar") { _, _ -> finish() }
                .show()
            return
        }

        actionBar?.hide()
        window.statusBarColor = 0xFF1B1633.toInt()
        val prefs = getSharedPreferences("bongo", MODE_PRIVATE)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFFF3F1FA.toInt())
        scroll.isFillViewport = true
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        scroll.addView(root)

        // ----- topo com a capa
        val header = FrameLayout(this)
        header.layoutParams = LinearLayout.LayoutParams(mp, dp(250))
        val cover = ImageView(this)
        cover.setImageResource(R.drawable.cover)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        header.addView(cover, FrameLayout.LayoutParams(mp, mp))
        val shade = View(this)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x221B1633, 0xF21B1633.toInt())
        )
        header.addView(shade, FrameLayout.LayoutParams(mp, mp))
        val ht = LinearLayout(this)
        ht.orientation = LinearLayout.VERTICAL
        ht.setPadding(dp(22), 0, dp(22), dp(24))
        val title = TextView(this)
        title.text = "Bongo Cat"
        title.textSize = 36f
        title.setTextColor(Color.WHITE)
        title.setTypeface(null, Typeface.BOLD)
        val sub = TextView(this)
        sub.text = "Um gato que digita e mexe o mouse com voce, em qualquer app"
        sub.textSize = 14f
        sub.setTextColor(0xCCFFFFFF.toInt())
        ht.addView(title)
        ht.addView(sub)
        val hlp = FrameLayout.LayoutParams(mp, wc)
        hlp.gravity = Gravity.BOTTOM
        header.addView(ht, hlp)
        root.addView(header)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(28))
        root.addView(content)

        // ----- cartao: comece aqui + status
        val c1 = card()
        c1.addView(heading("Comece aqui"))
        c1.addView(caption("Ligue os servicos nas configuracoes de acessibilidade. O app nao le nem guarda o que voce digita."))
        val cta = pill("Ligar o gato", accent)
        cta.textSize = 17f
        cta.setOnClickListener { openAccessibility() }
        val ctaLp = LinearLayout.LayoutParams(mp, wc)
        ctaLp.topMargin = dp(10)
        ctaLp.bottomMargin = dp(8)
        c1.addView(cta, ctaLp)
        val stCat = statusRow("Gato flutuante")
        val stKey = statusRow("Teclado fisico (jogos)")
        val stShz = statusRow("Shizuku")
        stCat.btn.setOnClickListener { openAccessibility() }
        stKey.btn.setOnClickListener { openAccessibility() }
        stShz.btn.setOnClickListener {
            shizukuAction()
            refreshAll?.invoke()
        }
        c1.addView(stCat.root)
        c1.addView(stKey.root)
        c1.addView(stShz.root)
        content.addView(c1)

        // ----- cartao: seu gato
        val c2 = card()
        c2.addView(heading("Seu gato"))
        c2.addView(caption("Escolher gato"))
        c2.addView(
            spinnerRow(
                prefs, "skin",
                arrayOf(
                    "Gato novo (com mouse)",
                    "Gato antigo",
                    "Plugin teclado",
                    "Plugin osu",
                    "Gamepad",
                    "Plugin mania"
                )
            )
        )
        c2.addView(caption("Expressao e acessorios (todos os gatos, menos o antigo)"))
        c2.addView(
            spinnerRow(
                prefs, "face",
                arrayOf(
                    "Nenhuma",
                    "Oculos escuros",
                    "Corado",
                    "Pedindo dinheiro",
                    "Tremendo",
                    "Chapeu do Luffy",
                    "Bone do Mario",
                    "Cabelo do Goku",
                    "Patinho de borracha",
                    "Faixa vermelha e espada"
                )
            )
        )
        c2.addView(seekRow(prefs, "Tamanho do gato", "w", 100, 420, 240, ""))
        c2.addView(seekRow(prefs, "Esticar na horizontal", "sx", 50, 200, 100, "%"))
        c2.addView(seekRow(prefs, "Esticar na vertical", "sy", 50, 200, 100, "%"))
        c2.addView(switchRow(prefs, "Fixar o gato (nao move e deixa tocar atras)", "lock", 0))
        content.addView(c2)

        // ----- cartao: mouse e teclado
        val c3 = card()
        c3.addView(heading("Mouse e teclado"))
        c3.addView(caption("Sensibilidade (alta pode mexer sozinho)"))
        c3.addView(
            segmented(listOf("Normal", "Alta"), prefs.getInt("sens", 0).coerceIn(0, 1)) { i ->
                prefs.edit().putInt("sens", i).apply()
            }
        )
        c3.addView(caption("Mouse fisico"))
        val mouseNote = caption("")
        val notes = listOf(
            "Seguro: o gato reage ao mouse sem bloquear os cliques.",
            "Completo: segue a direcao do mouse e funciona em jogos, mas em alguns celulares pode bloquear os cliques.",
            "Shizuku: le mouse, teclado e toques direto do sistema, sem bloquear nada (precisa do Shizuku ligado)."
        )
        val hw0 = prefs.getInt("hw", 0).coerceIn(0, 2)
        mouseNote.text = notes[hw0]
        c3.addView(
            segmented(listOf("Seguro", "Completo", "Shizuku"), hw0) { i ->
                prefs.edit().putInt("hw", i).apply()
                mouseNote.text = notes[i]
                if (i == 2) BongoService.instance?.restartExt()
            }
        )
        c3.addView(mouseNote)
        content.addView(c3)

        // ----- cartao: sons
        val c4 = card()
        c4.addView(heading("Sons"))
        c4.addView(switchRow(prefs, "Som de tecla", "ksnd", 1))
        c4.addView(switchRow(prefs, "Som de clique", "csnd", 1))
        c4.addView(seekRow(prefs, "Volume", "vol", 0, 100, 60, "%"))
        content.addView(c4)

        // ----- cartao: diagnostico
        val c5 = card()
        val dtitle = heading("Diagnostico  (toque para abrir)")
        val diag = TextView(this)
        diag.textSize = 12f
        diag.setTextColor(soft)
        diag.typeface = Typeface.MONOSPACE
        diag.visibility = View.GONE
        dtitle.setOnClickListener {
            diag.visibility = if (diag.visibility == View.GONE) View.VISIBLE else View.GONE
        }
        c5.addView(dtitle)
        c5.addView(diag)
        content.addView(c5)

        val foot = TextView(this)
        foot.text = "Feito com carinho"
        foot.gravity = Gravity.CENTER
        foot.textSize = 12f
        foot.setTextColor(soft)
        content.addView(foot)

        refreshAll = {
            val on = Settings.Secure.getString(
                contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            val catOn = on.contains("BongoService")
            val keyOn = on.contains("KeyService")
            paintStatus(
                stCat, catOn,
                if (catOn) "Ligado" else "Desligado - toque em Ativar",
                if (catOn) "Ajustes" else "Ativar"
            )
            paintStatus(
                stKey, keyOn,
                if (keyOn) "Ligado" else "Desligado - so para teclado fisico",
                if (keyOn) "Ajustes" else "Ativar"
            )
            val sOn = ShizukuInput.available()
            val sOk = ShizukuInput.granted()
            paintStatus(
                stShz, sOn,
                if (!sOn) "Desligado - toque para abrir o Shizuku"
                else if (!sOk) "Ligado - falta dar a permissao"
                else "Ligado - permissao ok",
                if (!sOn) "Abrir" else if (!sOk) "Permitir" else "OK"
            )
            diag.text = "Android: " + Build.VERSION.SDK_INT +
                "\nMovimentos do mouse lidos: " + Diag.motion +
                "\nTeclas fisicas lidas: " + Diag.keys +
                "\nHover: " + Diag.hover +
                "\nShizuku: " + (if (sOn) "rodando" else "desligado") +
                ", permissao " + (if (sOk) "ok" else "nao") +
                ", leitura " + (if (ShizukuInput.running) "ativa" else "parada") +
                " (" + ShizukuInput.lines + " linhas)" +
                "\nErro Shizuku: " + ShizukuInput.error +
                "\nErro: " + Diag.err
        }
        refreshAll?.invoke()

        setContentView(scroll)
    }
}
