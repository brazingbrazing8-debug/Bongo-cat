package com.example.bongocat

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Toast
import rikka.shizuku.Shizuku
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {
    private var refreshAll: (() -> Unit)? = null

    override fun onResume() {
        super.onResume()
        refreshAll?.invoke()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bongo", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(48, 48, 48, 48)

        val title = TextView(this)
        title.text = "Bongo Cat flutuante"
        title.textSize = 24f
        title.gravity = Gravity.CENTER

        val hint = TextView(this)
        hint.text = "1. Toque no botao abaixo.\n" +
            "2. Em Apps instalados / Servicos baixados, toque em Bongo Cat e ative.\n" +
            "3. O gato aparece e bate a pata quando voce digita em qualquer app.\n" +
            "Arraste o gato para mover. O app nao le o que voce digita."
        hint.setPadding(0, 16, 0, 16)

        val open = Button(this)
        open.text = "Abrir ajustes de acessibilidade"
        open.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // tamanho
        val sizeLabel = TextView(this)
        sizeLabel.gravity = Gravity.CENTER
        sizeLabel.textSize = 18f
        sizeLabel.setPadding(0, 24, 0, 8)
        fun refreshSize() {
            sizeLabel.text = "Tamanho do gato: " + prefs.getInt("w", 240)
        }
        fun change(delta: Int) {
            val v = (prefs.getInt("w", 240) + delta).coerceIn(100, 420)
            prefs.edit().putInt("w", v).apply()
            refreshSize()
        }
        refreshSize()
        val minus = Button(this)
        minus.text = "Diminuir  -"
        minus.setOnClickListener { change(-30) }
        val plus = Button(this)
        plus.text = "Aumentar  +"
        plus.setOnClickListener { change(30) }
        val sizeRow = LinearLayout(this)
        sizeRow.orientation = LinearLayout.HORIZONTAL
        sizeRow.gravity = Gravity.CENTER
        sizeRow.addView(minus)
        sizeRow.addView(plus)

        // escolher gato
        val skinLabel = TextView(this)
        skinLabel.text = "Escolher gato:"
        skinLabel.gravity = Gravity.CENTER
        skinLabel.textSize = 18f
        skinLabel.setPadding(0, 24, 0, 8)
        val names = arrayOf(
            "Gato novo (com mouse)",
            "Gato antigo",
            "Plugin teclado",
            "Plugin osu",
            "Gamepad",
            "Plugin mania"
        )
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val saved = prefs.getInt("skin", 0)
        val sel = if (saved in 0 until names.size) saved else 0
        if (sel != saved) prefs.edit().putInt("skin", sel).apply()
        spinner.setSelection(sel)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("skin", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // sensibilidade
        val sensLabel = TextView(this)
        sensLabel.gravity = Gravity.CENTER
        sensLabel.textSize = 18f
        sensLabel.setPadding(0, 24, 0, 8)
        fun refreshSens() {
            sensLabel.text = "Sensibilidade (alta pode mexer sozinho): " +
                (if (prefs.getInt("sens", 0) == 1) "alta" else "normal")
        }
        refreshSens()
        val sensNormal = Button(this)
        sensNormal.text = "Normal"
        sensNormal.setOnClickListener {
            prefs.edit().putInt("sens", 0).apply()
            refreshSens()
        }
        val sensHigh = Button(this)
        sensHigh.text = "Alta"
        sensHigh.setOnClickListener {
            prefs.edit().putInt("sens", 1).apply()
            refreshSens()
        }
        val sensRow = LinearLayout(this)
        sensRow.orientation = LinearLayout.HORIZONTAL
        sensRow.gravity = Gravity.CENTER
        sensRow.addView(sensNormal)
        sensRow.addView(sensHigh)

        val keyNote = TextView(this)
        keyNote.text = "Teclado fisico (Minecraft e outros jogos): ligue tambem o servico \"Bongo Cat Teclado\" nas configuracoes de acessibilidade. Se bloquear teclas, desligue so esse servico."
        keyNote.gravity = Gravity.CENTER
        keyNote.setPadding(0, 24, 0, 8)
        val hwLabel = TextView(this)
        hwLabel.gravity = Gravity.CENTER
        hwLabel.textSize = 18f
        hwLabel.setPadding(0, 24, 0, 8)
        fun refreshHw() {
            hwLabel.text = "Mouse fisico: " + when (prefs.getInt("hw", 0)) {
                1 -> "completo"
                2 -> "shizuku"
                else -> "seguro"
            }
        }
        refreshHw()
        val hwNote = TextView(this)
        hwNote.text = "Seguro: o gato reage ao mouse sem bloquear os cliques. Completo: segue a direcao do mouse e funciona em jogos, mas em alguns celulares pode bloquear os cliques do mouse. Shizuku: le o mouse, o teclado e os toques direto do sistema, sem bloquear nada (precisa do app Shizuku rodando e da permissao abaixo). Se algo travar, volte para Seguro."
        hwNote.gravity = Gravity.CENTER
        val hwOff = Button(this)
        hwOff.text = "Seguro"
        hwOff.setOnClickListener {
            prefs.edit().putInt("hw", 0).apply()
            refreshHw()
        }
        val hwOn = Button(this)
        hwOn.text = "Completo"
        hwOn.setOnClickListener {
            prefs.edit().putInt("hw", 1).apply()
            refreshHw()
        }
        val hwRow = LinearLayout(this)
        hwRow.orientation = LinearLayout.HORIZONTAL
        hwRow.gravity = Gravity.CENTER
        hwRow.addView(hwOff)
        hwRow.addView(hwOn)
        val hwShz = Button(this)
        hwShz.text = "Shizuku"
        hwShz.setOnClickListener {
            prefs.edit().putInt("hw", 2).apply()
            BongoService.instance?.restartExt()
            refreshHw()
        }
        hwRow.addView(hwShz)
        val shzPerm = Button(this)
        shzPerm.text = "Permissao do Shizuku"
        shzPerm.setOnClickListener {
            try {
                if (!Shizuku.pingBinder()) {
                    Toast.makeText(
                        this,
                        "Abra o app Shizuku e inicie ele primeiro",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Shizuku.requestPermission(1234)
                }
            } catch (t: Throwable) {
                Toast.makeText(this, "Shizuku nao encontrado", Toast.LENGTH_LONG).show()
            }
        }

        val diag = TextView(this)
        diag.gravity = Gravity.CENTER
        diag.setPadding(0, 16, 0, 8)
        fun refreshDiag() {
            val on = Settings.Secure.getString(
                contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            diag.text = "Servico Bongo Cat: " + (if (on.contains("BongoService")) "ligado" else "DESLIGADO") +
                "\nServico Teclado: " + (if (on.contains("KeyService")) "ligado" else "DESLIGADO") +
                "\nAndroid: " + Build.VERSION.SDK_INT +
                "\nMovimentos do mouse lidos: " + Diag.motion +
                "\nTeclas fisicas lidas: " + Diag.keys +
                "\nHover: " + Diag.hover +
                "\nShizuku: " + (if (ShizukuInput.available()) "rodando" else "desligado") +
                ", permissao " + (if (ShizukuInput.granted()) "ok" else "nao") +
                ", leitura " + (if (ShizukuInput.running) "ativa" else "parada") +
                " (" + ShizukuInput.lines + " linhas)" +
                "\nErro Shizuku: " + ShizukuInput.error +
                "\nErro: " + Diag.err
        }
        refreshDiag()
        refreshAll = { refreshDiag() }
        val diagBtn = Button(this)
        diagBtn.text = "Atualizar diagnostico"
        diagBtn.setOnClickListener { refreshDiag() }

        val cover = ImageView(this)
        cover.setImageResource(R.drawable.cover)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(
            cover,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (190 * resources.displayMetrics.density).toInt()
            )
        )

        fun makeToggle(title: String, key: String, def: Int = 1): List<View> {
            val label = TextView(this)
            label.gravity = Gravity.CENTER
            label.textSize = 18f
            label.setPadding(0, 24, 0, 8)
            fun refresh() {
                label.text = title + ": " + (if (prefs.getInt(key, def) == 1) "ligado" else "desligado")
            }
            refresh()
            val off = Button(this)
            off.text = "Desligar"
            off.setOnClickListener {
                prefs.edit().putInt(key, 0).apply()
                refresh()
            }
            val on = Button(this)
            on.text = "Ligar"
            on.setOnClickListener {
                prefs.edit().putInt(key, 1).apply()
                refresh()
            }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            row.addView(off)
            row.addView(on)
            return listOf(label, row)
        }

        val volLabel = TextView(this)
        volLabel.gravity = Gravity.CENTER
        volLabel.textSize = 18f
        volLabel.setPadding(0, 24, 0, 8)
        fun refreshVol() {
            volLabel.text = "Volume dos sons: " + prefs.getInt("vol", 60) + "%"
        }
        fun changeVol(delta: Int) {
            val v = (prefs.getInt("vol", 60) + delta).coerceIn(0, 100)
            prefs.edit().putInt("vol", v).apply()
            refreshVol()
        }
        refreshVol()
        val volMinus = Button(this)
        volMinus.text = "Menos -"
        volMinus.setOnClickListener { changeVol(-20) }
        val volPlus = Button(this)
        volPlus.text = "Mais +"
        volPlus.setOnClickListener { changeVol(20) }
        val volRow = LinearLayout(this)
        volRow.orientation = LinearLayout.HORIZONTAL
        volRow.gravity = Gravity.CENTER
        volRow.addView(volMinus)
        volRow.addView(volPlus)

        root.addView(title)
        root.addView(hint)
        root.addView(open)
        root.addView(sizeLabel)
        root.addView(sizeRow)
        root.addView(skinLabel)
        root.addView(spinner)

        val faceLabel = TextView(this)
        faceLabel.text = "Expressao do gato (so nos gatos Plugin):"
        faceLabel.gravity = Gravity.CENTER
        faceLabel.setPadding(0, 24, 0, 8)
        val faceNames = arrayOf(
            "Nenhuma",
            "Oculos escuros",
            "Corado",
            "Pedindo dinheiro",
            "Tremendo"
        )
        val faceSpinner = Spinner(this)
        faceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, faceNames)
        faceSpinner.setSelection(prefs.getInt("face", 0).coerceIn(0, faceNames.size - 1))
        faceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("face", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(faceLabel)
        root.addView(faceSpinner)

        val accLabel = TextView(this)
        accLabel.text = "Acessorios (gato novo e gatos Plugin):"
        accLabel.gravity = Gravity.CENTER
        accLabel.setPadding(0, 24, 0, 8)
        root.addView(accLabel)
        for (v in makeToggle("Oculos pretos", "accg", 0)) root.addView(v)
        val hatNames = arrayOf("Sem chapeu", "Capacete do Minecraft", "Chapeu do Luffy")
        val hatSpinner = Spinner(this)
        hatSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, hatNames)
        hatSpinner.setSelection(prefs.getInt("acch", 0).coerceIn(0, hatNames.size - 1))
        hatSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("acch", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(hatSpinner)
        root.addView(sensLabel)
        root.addView(sensRow)
        root.addView(keyNote)
        root.addView(hwLabel)
        root.addView(hwNote)
        root.addView(hwRow)
        root.addView(shzPerm)
        for (v in makeToggle("Som de tecla", "ksnd")) root.addView(v)
        for (v in makeToggle("Som de clique", "csnd")) root.addView(v)
        root.addView(volLabel)
        root.addView(volRow)
        root.addView(diag)
        root.addView(diagBtn)

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)
    }
}
