package com.example.bongocat

object Pads {
    val P: Map<String, Float> = mapOf(
        "ov0_a" to 0.00f,
        "ov0_b" to 0.00f,
        "ov0_c" to 0.07f,
        "ov1_a" to 0.00f,
        "ov1_b" to 0.00f,
        "ov1_c" to 0.00f,
        "ov2_a" to 0.00f,
        "ov2_b" to 0.00f,
        "ov2_c" to 0.07f,
        "ov3_a" to 0.00f,
        "ov3_b" to 0.00f,
        "ov3_c" to 0.00f,
        "ov4_a" to 0.15f,
        "ov4_b" to 0.00f,
        "ov4_c" to 0.00f,
        "ov5_a" to 0.15f,
        "ov5_b" to 0.00f,
        "ov5_c" to 0.07f,
        "ov6_a" to 0.50f,
        "ov6_b" to 0.37f,
        "ov6_c" to 0.37f
    )
}
