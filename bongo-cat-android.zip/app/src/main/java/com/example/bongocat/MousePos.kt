package com.example.bongocat

object MousePos {
    val X = floatArrayOf(64.2f, 64.2f, 64.9f, 65.2f, 65.4f, 66.0f, 66.0f, 66.5f, 67.2f, 67.9f, 68.1f, 68.2f, 68.8f, 69.2f, 69.8f, 70.3f, 71.5f, 71.5f, 71.6f, 71.8f, 74.0f, 74.0f, 74.2f, 74.3f, 74.6f, 75.3f, 75.4f, 76.0f, 76.4f, 76.4f, 77.2f, 77.6f, 78.4f)
    val Y = floatArrayOf(139.2f, 140.0f, 138.8f, 140.3f, 138.4f, 138.5f, 138.0f, 139.6f, 139.5f, 137.5f, 137.8f, 138.5f, 139.2f, 138.2f, 138.8f, 137.4f, 140.0f, 135.5f, 140.4f, 134.2f, 138.7f, 133.3f, 133.7f, 138.0f, 137.1f, 133.3f, 134.4f, 133.4f, 137.2f, 134.1f, 136.0f, 135.7f, 135.4f)
    const val REST_IDX = 15
    const val REST_X = 70.3f
    const val REST_Y = 137.4f
    val MIN_X = X.min()
    val MAX_X = X.max()
    val MIN_Y = Y.min()
    val MAX_Y = Y.max()
}
