package com.example.bongocat

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.SoundPool
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import kotlin.math.abs

class BongoService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var cat: CatView
    private var root: FrameLayout? = null

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var idle: Drawable
    private val typing = ArrayList<Drawable>()
    private val mouse = ArrayList<Drawable>()
    private val held = HashSet<Int>()

    private var skin = 0
    private var tIdx = 0
    private var mIdx = 0

    private var lastKey = 0L
    private var lastKeyAny = 0L
    private var lastMouse = 0L
    private var lastLoose = 0L
    private var widthDp = 240
    private var aspect = 0.5f
    private var density = 1f
    private var sens = 0
    private var facePref = 0
    private var accGlasses = 0
    private var accHat = 0
    private var hw = 0

    private var mx = MousePos.REST_X
    private var my = MousePos.REST_Y
    private var posX = MousePos.X
    private var posY = MousePos.Y
    private var restIdx = MousePos.REST_IDX
    private var restX = MousePos.REST_X
    private var restY = MousePos.REST_Y
    private var minX = MousePos.MIN_X
    private var maxX = MousePos.MAX_X
    private var minY = MousePos.MIN_Y
    private var maxY = MousePos.MAX_Y
    private var jitter = 1f
    private var lastSX = 0
    private var lastSY = 0
    private var lastPX = 0f
    private var lastPY = 0f
    private var havePointer = false

    private val tick = Runnable { render() }

    private var sp: SoundPool? = null
    private val keyIds = IntArray(3)
    private var clickId = 0
    private var kSound = true
    private var cSound = true
    private var vol = 0.6f
    private var lastClickSnd = 0L

    companion object {
        @Volatile
        var instance: BongoService? = null
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
        if (key == "ksnd") {
            kSound = p.getInt("ksnd", 1) == 1
        } else if (key == "csnd") {
            cSound = p.getInt("csnd", 1) == 1
        } else if (key == "vol") {
            vol = p.getInt("vol", 60) / 100f
        } else if (key == "accg") {
            accGlasses = p.getInt("accg", 0)
            if (root != null) applyAcc()
        } else if (key == "acch") {
            accHat = p.getInt("acch", 0)
            if (root != null) applyAcc()
        } else if (key == "face") {
            facePref = p.getInt("face", 0)
            if (root != null) applyFace()
        } else if (key == "sens") {
            sens = p.getInt("sens", 0)
        } else if (key == "hw") {
            hw = p.getInt("hw", 0)
            applyHw()
        } else if (key == "w") {
            widthDp = p.getInt("w", 240)
            relayout()
        } else if (key == "skin") {
            if (root != null) {
                loadSkin(p.getInt("skin", 0))
                applyFace()
                applyAcc()
                relayout()
                render()
            }
        }
    }

    private fun relayout() {
        if (root != null) {
            computeSize()
            wm.updateViewLayout(root, params)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        hw = getSharedPreferences("bongo", MODE_PRIVATE).getInt("hw", 0)
        applyHw()
        if (root == null) createOverlay()
    }

    fun extMove(dx: Float, dy: Float, force: Boolean) {
        mouseMove(dx, dy, force)
    }

    fun extClick() {
        playClick()
        mouseHit(true)
    }

    fun restartExt() {
        ShizukuInput.stop()
        if (hw == 2) ShizukuInput.start()
    }

    private fun applyHw() {
        if (hw == 2) ShizukuInput.start() else ShizukuInput.stop()
        try {
            val info = serviceInfo ?: return
            if (Build.VERSION.SDK_INT >= 34) {
                info.motionEventSources = if (hw == 1) {
                    InputDevice.SOURCE_MOUSE or InputDevice.SOURCE_MOUSE_RELATIVE
                } else {
                    0
                }
            }
            serviceInfo = info
            Diag.err = "nenhum"
        } catch (t: Throwable) {
            Diag.err = t.toString()
        }
    }

    override fun onMotionEvent(event: MotionEvent) {
        Diag.motion++
        if (root == null) return
        val relative = (event.source and InputDevice.SOURCE_MOUSE_RELATIVE) ==
            InputDevice.SOURCE_MOUSE_RELATIVE
        var dx = 0f
        var dy = 0f
        if (relative) {
            dx = event.getAxisValue(MotionEvent.AXIS_RELATIVE_X)
            dy = event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y)
        } else {
            if (havePointer) {
                dx = event.rawX - lastPX
                dy = event.rawY - lastPY
            }
            lastPX = event.rawX
            lastPY = event.rawY
            havePointer = true
        }
        val a = event.actionMasked
        if (a == MotionEvent.ACTION_BUTTON_PRESS || a == MotionEvent.ACTION_DOWN) {
            playClick()
            mouseHit(true)
        } else if (dx != 0f || dy != 0f) {
            mouseMove(dx / 6f, dy / 6f, true)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (root == null || event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> typeHit()
            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED -> if (sens == 1) typeHit()
            AccessibilityEvent.TYPE_VIEW_HOVER_ENTER,
            AccessibilityEvent.TYPE_VIEW_HOVER_EXIT -> {
                Diag.hover++
                mouseHit(true)
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> scrolled(event)
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> {
                playClick()
                mouseHit()
            }
            AccessibilityEvent.TYPE_VIEW_SELECTED,
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> if (sens == 1) mouseHit()
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> if (sens == 1) mouseHit()
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> if (sens == 1) {
                val now = SystemClock.uptimeMillis()
                if (now - lastLoose >= 120) {
                    lastLoose = now
                    val text = event.contentChangeTypes and AccessibilityEvent.CONTENT_CHANGE_TYPE_TEXT
                    if (text != 0) typeHit() else mouseHit()
                }
            }
        }
    }

    override fun onInterrupt() {}

    fun keyDown(code: Int, repeat: Boolean) {
        lastKeyAny = SystemClock.uptimeMillis()
        held.add(code)
        if (!repeat) typeHit(code) else render()
    }

    fun keyUp(code: Int) {
        held.remove(code)
        render()
    }

    private fun load(prefix: String, into: ArrayList<Drawable>) {
        var i = 0
        while (true) {
            val id = resources.getIdentifier("%s%02d".format(prefix, i), "drawable", packageName)
            if (id == 0) break
            into.add(resources.getDrawable(id, null))
            i++
        }
    }

    private fun drawable(name: String): Drawable {
        return resources.getDrawable(resources.getIdentifier(name, "drawable", packageName), null)
    }

    private fun loadSkin(wanted: Int) {
        val s = if (wanted in 0..5) wanted else 0
        skin = s
        typing.clear()
        mouse.clear()
        held.clear()
        tIdx = 0
        mIdx = if (s == 0) restIdx else 0
        mx = restX
        my = restY
        if (s == 1) {
            load("o", typing)
            idle = typing.removeAt(4)
            aspect = 206f / 300f
        } else if (s in 2..5) {
            val pre = when (s) {
                2 -> "k"
                3 -> "s"
                5 -> "n"
                else -> "c"
            }
            idle = drawable(pre + "idle")
            load(pre, typing)
            aspect = 354f / 612f
        } else {
            load("t", typing)
            load("d", mouse)
            idle = mouse[restIdx.coerceAtMost(mouse.size - 1)]
            aspect = 0.5f
        }
    }

    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
        val prefs = getSharedPreferences("bongo", MODE_PRIVATE)
        widthDp = prefs.getInt("w", 240)
        sens = prefs.getInt("sens", 0)
        facePref = prefs.getInt("face", 0)
        accGlasses = prefs.getInt("accg", 0)
        accHat = prefs.getInt("acch", 0)
        kSound = prefs.getInt("ksnd", 1) == 1
        cSound = prefs.getInt("csnd", 1) == 1
        vol = prefs.getInt("vol", 60) / 100f
        initSound()
        loadSkin(prefs.getInt("skin", 0))
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)

        params = WindowManager.LayoutParams(
            10, 10,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 50
        params.y = 300

        val r = FrameLayout(this)
        cat = CatView(this)
        cat.base = idle
        applyFace()
        applyAcc()
        r.addView(cat, FrameLayout.LayoutParams(10, 10))

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var lastX = 0f
        var lastY = 0f
        var moved = false
        cat.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    lastX = e.rawX; lastY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    val ddx = e.rawX - lastX
                    val ddy = e.rawY - lastY
                    lastX = e.rawX
                    lastY = e.rawY
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        wm.updateViewLayout(r, params)
                        mouseMove(ddx / 8f, ddy / 8f, true)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) typeHit()
            }
            true
        }

        var hx = 0f
        var hy = 0f
        var hov = false
        cat.setOnHoverListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_HOVER_MOVE) {
                if (hov) mouseMove((e.rawX - hx) / 6f, (e.rawY - hy) / 6f, true)
                hx = e.rawX
                hy = e.rawY
                hov = true
            } else if (e.actionMasked == MotionEvent.ACTION_HOVER_EXIT) {
                hov = false
            }
            false
        }

        root = r
        computeSize()
        wm.addView(r, params)
    }

    private fun computeSize() {
        val w = (widthDp * density).toInt()
        val h = (w * aspect).toInt()
        params.width = w
        params.height = h
        cat.layoutParams = FrameLayout.LayoutParams(w, h)
    }

    private fun typeHit(code: Int = -1) {
        if (root == null) return
        if (typing.isEmpty()) return
        val now = SystemClock.uptimeMillis()
        if (now - lastKey < 10) return
        lastKey = now
        lastKeyAny = now
        playKey()
        tIdx = if (code >= 0) {
            code % typing.size
        } else {
            (tIdx + 1) % typing.size
        }
        render()
    }

    private fun mouseHit(force: Boolean = false) {
        jitter = -jitter
        mouseMove(3f * jitter, 0f, force)
    }

    private fun scrolled(e: AccessibilityEvent) {
        var dx = -e.scrollDeltaX.toFloat()
        var dy = -e.scrollDeltaY.toFloat()
        if (e.scrollDeltaX == 0 && e.scrollDeltaY == 0) {
            if (e.scrollX >= 0) dx = -(e.scrollX - lastSX).toFloat()
            if (e.scrollY >= 0) dy = -(e.scrollY - lastSY).toFloat()
        }
        lastSX = e.scrollX
        lastSY = e.scrollY
        if (dx == 0f && dy == 0f) {
            mouseHit()
            return
        }
        mouseMove((dx / 40f).coerceIn(-4f, 4f), (dy / 40f).coerceIn(-4f, 4f))
    }

    private fun mouseMove(dx: Float, dy: Float, force: Boolean = false) {
        if (root == null) return
        if (mouse.isEmpty()) return
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastKeyAny < 600) return
        mx = (mx + dx).coerceIn(minX, maxX)
        my = (my + dy).coerceIn(minY, maxY)
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in posX.indices) {
            val ex = posX[i] - mx
            val ey = posY[i] - my
            val dist = ex * ex + ey * ey
            if (dist < bd) {
                bd = dist
                best = i
            }
        }
        mIdx = if (best < mouse.size) best else 0
        lastMouse = now
        render()
    }

    private fun render() {
        if (root == null) return
        val now = SystemClock.uptimeMillis()
        if (held.isNotEmpty() && now - lastKeyAny > 10000) held.clear()
        val keyActive = typing.isNotEmpty() && (held.isNotEmpty() || now - lastKey < 160)
        val mouseActive = mouse.isNotEmpty() && now - lastMouse < 300
        var b: Drawable = idle
        var o: Drawable? = null
        if (keyActive) {
            b = typing[tIdx]
            if (mouse.isNotEmpty()) o = mouse[mIdx]
        } else if (mouseActive) {
            b = mouse[mIdx]
        }
        cat.base = b
        cat.over = o
        cat.invalidate()
        handler.removeCallbacks(tick)
        if (keyActive || mouseActive) {
            handler.postDelayed(tick, 40)
        } else {
            mx = restX
            my = restY
            if (skin == 0) mIdx = restIdx
        }
    }

    private fun applyAcc() {
        val fam = when (skin) {
            0 -> "a"
            2, 3, 5 -> "b"
            else -> ""
        }
        val list = ArrayList<Drawable>()
        if (fam.isNotEmpty()) {
            if (accGlasses == 1) list.add(drawable("acc_g_" + fam))
            if (accHat in 1..2) list.add(drawable("acc_h" + accHat + "_" + fam))
        }
        cat.accs = list
        cat.invalidate()
    }

    private fun applyFace() {
        val f = if (skin == 2 || skin == 3 || skin == 5) facePref else 0
        cat.face = if (f in 1..4) drawable("face" + (f - 1)) else null
        cat.invalidate()
    }

    private fun initSound() {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val pool = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
            keyIds[0] = pool.load(this, R.raw.key1, 1)
            keyIds[1] = pool.load(this, R.raw.key2, 1)
            keyIds[2] = pool.load(this, R.raw.key3, 1)
            clickId = pool.load(this, R.raw.click, 1)
            sp = pool
        } catch (t: Throwable) {
            sp = null
        }
    }

    private fun playKey() {
        val pool = sp ?: return
        if (!kSound || vol <= 0f) return
        val rate = 0.94f + kotlin.random.Random.nextFloat() * 0.12f
        pool.play(keyIds[kotlin.random.Random.nextInt(3)], vol, vol, 1, 0, rate)
    }

    private fun playClick() {
        val pool = sp ?: return
        if (!cSound || vol <= 0f) return
        val now = SystemClock.uptimeMillis()
        if (now - lastClickSnd < 70) return
        lastClickSnd = now
        pool.play(clickId, vol, vol, 1, 0, 1f)
    }

    override fun onDestroy() {
        ShizukuInput.stop()
        sp?.release()
        sp = null
        instance = null
        getSharedPreferences("bongo", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener)
        handler.removeCallbacksAndMessages(null)
        root?.let { wm.removeView(it) }
        root = null
        super.onDestroy()
    }
}
