package com.example.bongocat

import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.abs
import rikka.shizuku.Shizuku

object ShizukuInput {
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var proc: Process? = null
    @Volatile private var gen = 0
    @Volatile var running = false
    @Volatile var lines = 0
    @Volatile var error = "nenhum"

    private const val NONE = Int.MIN_VALUE
    private var relX = 0
    private var relY = 0
    private var slot = 0
    private val tx = IntArray(16) { NONE }
    private val ty = IntArray(16) { NONE }
    private var tdx = 0
    private var tdy = 0
    private var lastPost = 0L

    fun available(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (t: Throwable) {
            false
        }
    }

    fun granted(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (t: Throwable) {
            false
        }
    }

    fun start() {
        if (running) return
        if (!available()) {
            error = "Shizuku nao esta rodando"
            return
        }
        if (!granted()) {
            error = "Sem permissao do Shizuku"
            return
        }
        gen++
        val my = gen
        running = true
        error = "nenhum"
        lines = 0
        Thread {
            try {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                )
                m.isAccessible = true
                val p = m.invoke(null, arrayOf("getevent", "-l"), null, null) as Process
                proc = p
                val r = BufferedReader(InputStreamReader(p.inputStream))
                while (running && my == gen) {
                    val line = r.readLine() ?: break
                    lines++
                    parse(line)
                }
                if (running && my == gen) error = "getevent parou"
            } catch (t: Throwable) {
                if (my == gen) error = t.toString()
            } finally {
                if (my == gen) {
                    running = false
                    try {
                        proc?.destroy()
                    } catch (t: Throwable) {
                    }
                    proc = null
                }
            }
        }.start()
    }

    fun stop() {
        gen++
        running = false
        try {
            proc?.destroy()
        } catch (t: Throwable) {
        }
        proc = null
    }

    private fun hex(v: String): Int {
        return try {
            java.lang.Long.parseLong(v, 16).toInt()
        } catch (e: Exception) {
            0
        }
    }

    private fun parse(line: String) {
        val t = line.trim().split(Regex("\\s+"))
        if (t.size < 4) return
        val type = t[1]
        val code = t[2]
        val value = t[3]
        if (type == "EV_REL") {
            if (code == "REL_X") relX += hex(value)
            else if (code == "REL_Y") relY += hex(value)
        } else if (type == "EV_ABS") {
            if (code == "ABS_MT_SLOT") {
                slot = hex(value).coerceIn(0, 15)
            } else if (code == "ABS_MT_TRACKING_ID") {
                if (hex(value) == -1) {
                    tx[slot] = NONE
                    ty[slot] = NONE
                }
            } else if (code == "ABS_MT_POSITION_X") {
                val v = hex(value)
                if (tx[slot] != NONE) {
                    val d = v - tx[slot]
                    if (abs(d) > abs(tdx)) tdx = d
                }
                tx[slot] = v
            } else if (code == "ABS_MT_POSITION_Y") {
                val v = hex(value)
                if (ty[slot] != NONE) {
                    val d = v - ty[slot]
                    if (abs(d) > abs(tdy)) tdy = d
                }
                ty[slot] = v
            }
        } else if (type == "EV_KEY") {
            val down = value == "DOWN" || value == "00000001"
            val up = value == "UP" || value == "00000000"
            if (code == "BTN_LEFT" || code == "BTN_RIGHT" || code == "BTN_MIDDLE" ||
                code == "BTN_SIDE" || code == "BTN_EXTRA"
            ) {
                if (down) main.post { BongoService.instance?.extClick() }
            } else if (code.startsWith("KEY_")) {
                val id = code.hashCode() and 0x7fffffff
                if (down) {
                    main.post { BongoService.instance?.keyDown(id, false) }
                } else if (up) {
                    main.post { BongoService.instance?.keyUp(id) }
                }
            }
        } else if (type == "EV_SYN" && code == "SYN_REPORT") {
            val now = SystemClock.uptimeMillis()
            if (now - lastPost < 8) return
            lastPost = now
            if (relX != 0 || relY != 0) {
                val f = BongoService.speedFactor()
                val dx = relX / 4f * f
                val dy = relY / 4f * f
                relX = 0
                relY = 0
                main.post { BongoService.instance?.extMove(dx, dy, true) }
            }
            if (abs(tdx) > 6 || abs(tdy) > 6) {
                val f = BongoService.speedFactor()
                val dx = tdx / 10f * f
                val dy = tdy / 10f * f
                main.post { BongoService.instance?.extMove(dx, dy, false) }
            }
            tdx = 0
            tdy = 0
        }
    }
}
