package com.example.bongocat

object Neighbors {
    val A: Array<IntArray> = arrayOf(
        intArrayOf(12, 11, 4, 13),
        intArrayOf(9, 20, 14, 2),
        intArrayOf(7, 14, 1, 20),
        intArrayOf(5, 12, 6, 13),
        intArrayOf(11, 15, 0, 13),
        intArrayOf(6, 3, 16, 12),
        intArrayOf(5, 16, 3, 7),
        intArrayOf(2, 14, 6, 1),
        intArrayOf(20, 9, 1, 14),
        intArrayOf(20, 1, 14, 2),
        intArrayOf(15, 4, 19, 11),
        intArrayOf(4, 0, 13, 12),
        intArrayOf(3, 0, 13, 11),
        intArrayOf(11, 12, 3, 17),
        intArrayOf(1, 2, 9, 20),
        intArrayOf(4, 10, 11, 19),
        intArrayOf(6, 5, 18, 14),
        intArrayOf(13, 5, 3, 6),
        intArrayOf(16, 3, 5, 6),
        intArrayOf(15, 4, 10, 11),
        intArrayOf(9, 1, 14, 8)
    )
    val B: Array<IntArray> = arrayOf(
        intArrayOf(12, 11, 4, 13),
        intArrayOf(9, 20, 14, 2),
        intArrayOf(7, 14, 1, 20),
        intArrayOf(5, 12, 6, 13),
        intArrayOf(11, 15, 0, 13),
        intArrayOf(6, 3, 16, 12),
        intArrayOf(5, 16, 3, 7),
        intArrayOf(2, 14, 6, 1),
        intArrayOf(20, 9, 1, 14),
        intArrayOf(20, 1, 14, 2),
        intArrayOf(15, 4, 19, 11),
        intArrayOf(4, 0, 13, 12),
        intArrayOf(3, 0, 13, 11),
        intArrayOf(11, 12, 3, 17),
        intArrayOf(1, 2, 9, 20),
        intArrayOf(4, 10, 11, 19),
        intArrayOf(6, 5, 18, 14),
        intArrayOf(13, 5, 3, 6),
        intArrayOf(16, 3, 5, 6),
        intArrayOf(15, 4, 10, 11),
        intArrayOf(9, 1, 14, 8),
        intArrayOf(22, 23, 24, 8),
        intArrayOf(21, 24, 23, 8),
        intArrayOf(21, 24, 22, 8),
        intArrayOf(21, 22, 23, 8)
    )
    val C: Array<IntArray> = arrayOf(
        intArrayOf(1, 2, 3, 4),
        intArrayOf(0, 2, 3, 4),
        intArrayOf(0, 1, 3, 4),
        intArrayOf(4, 1, 2, 0),
        intArrayOf(3, 1, 2, 0),
        intArrayOf(7, 8, 6, 2),
        intArrayOf(8, 5, 7, 2),
        intArrayOf(5, 8, 6, 2),
        intArrayOf(6, 5, 7, 2)
    )
}
