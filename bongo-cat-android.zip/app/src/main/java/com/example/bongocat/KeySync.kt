package com.example.bongocat

import android.view.KeyEvent

object KeySync {
    // Traduz o codigo da tecla fisica do Android para o nome que o plugin usa
    // (lctrl, lshift, r, up, down, left, right, ou as teclas do modo osu).
    fun androidKeyName(keyCode: Int): String? = when (keyCode) {
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "lctrl"
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "lshift"
        KeyEvent.KEYCODE_DPAD_UP -> "up"
        KeyEvent.KEYCODE_DPAD_DOWN -> "down"
        KeyEvent.KEYCODE_DPAD_LEFT -> "left"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
        KeyEvent.KEYCODE_R -> "r"
        KeyEvent.KEYCODE_Q -> "q"
        KeyEvent.KEYCODE_E -> "e"
        KeyEvent.KEYCODE_A -> "a"
        KeyEvent.KEYCODE_D -> "d"
        KeyEvent.KEYCODE_S -> "s"
        KeyEvent.KEYCODE_W -> "w"
        KeyEvent.KEYCODE_SPACE -> "space"
        KeyEvent.KEYCODE_1 -> "1"
        KeyEvent.KEYCODE_2 -> "2"
        KeyEvent.KEYCODE_3 -> "3"
        KeyEvent.KEYCODE_4 -> "4"
        KeyEvent.KEYCODE_5 -> "5"
        KeyEvent.KEYCODE_6 -> "6"
        KeyEvent.KEYCODE_7 -> "7"
        else -> null
    }

    // Indice do quadro certo para a tecla, ou -1 se essa tecla nao existe nesse gato.
    fun frameFor(skin: Int, keyCode: Int): Int {
        val name = androidKeyName(keyCode) ?: return -1
        val list = when (skin) {
            2 -> KeyMaps.K_TECLADO
            3 -> KeyMaps.S_OSU
            else -> return -1
        }
        return list.indexOf(name)
    }
}
