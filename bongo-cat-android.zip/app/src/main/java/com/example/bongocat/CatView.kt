package com.example.bongocat

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.view.View

class CatView(ctx: Context) : View(ctx) {
    var base: Drawable? = null
    var over: Drawable? = null
    var clip = 0.47f

    override fun onDraw(c: Canvas) {
        val w = width
        val h = height
        base?.let {
            it.setBounds(0, 0, w, h)
            it.draw(c)
        }
        over?.let {
            c.save()
            c.clipRect(0f, 0f, w * clip, h.toFloat())
            it.setBounds(0, 0, w, h)
            it.draw(c)
            c.restore()
        }
    }
}
