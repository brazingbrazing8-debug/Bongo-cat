package com.example.bongocat

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.view.View

class CatView(ctx: Context) : View(ctx) {
    var base: Drawable? = null
    var over: Drawable? = null
    var clip = 0.47f
    var face: Drawable? = null
    var hat: Drawable? = null
    var pad = 0f

    override fun onDraw(c: Canvas) {
        val w = width
        val h = height
        val ph = if (pad > 0f) (h * pad / (1f + pad)).toInt() else 0
        base?.let {
            it.setBounds(0, ph, w, h)
            it.draw(c)
        }
        over?.let {
            c.save()
            c.clipRect(0f, ph.toFloat(), w * clip, h.toFloat())
            it.setBounds(0, ph, w, h)
            it.draw(c)
            c.restore()
        }
        face?.let {
            it.setBounds(0, ph, w, h)
            it.draw(c)
        }
        hat?.let {
            it.setBounds(0, 0, w, h)
            it.draw(c)
        }
    }
}
