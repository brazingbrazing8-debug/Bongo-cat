# Ofuscacao e remocao de codigo nao usado (R8), mantendo o app funcionando.

# Componentes do Android citados no AndroidManifest (Activity/Service) ja sao
# mantidos automaticamente pelas regras padrao do Android Gradle Plugin.

# Biblioteca Shizuku: usa reflexao e tem API publica que precisa continuar
# com os mesmos nomes, senao o app quebra ao falar com o Shizuku.
-keep class rikka.shizuku.** { *; }
-keepclassmembers class rikka.shizuku.** { *; }
-dontwarn rikka.shizuku.**

# Nossa verificacao de assinatura e os objetos simples de dados: mantemos a
# classe para a reflexao do sistema Android (listeners), mas o resto do
# codigo do app pode ser embaralhado e reduzido normalmente.
-keepclassmembers class com.example.bongocat.MousePos { *; }
-keepclassmembers class com.example.bongocat.PenPos { *; }
-keepclassmembers class com.example.bongocat.Pads { *; }
-keepclassmembers class com.example.bongocat.Neighbors { *; }
-keepclassmembers class com.example.bongocat.Diag { *; }

# Mantem informacoes de linha para facilitar o diagnostico de problemas.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
